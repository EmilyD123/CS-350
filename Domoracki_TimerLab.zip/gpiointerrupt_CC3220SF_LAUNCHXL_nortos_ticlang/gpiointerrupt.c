/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
*/

/*
 * Emily Domoracki, Milestone 3
 * CS-350 SNHU C-4 2024
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// Morse code + Button States
enum MC_STATES {MC_SOS, MC_OK} BUTTON_STATE, BUTTON_INIT;

unsigned char i = 0;
unsigned char ledState;

//Transitions as arrays
int sosLEDs[] = {
                      1,0,1,0,1,              // 2500ms (dot dot dot)
                      0,0,0,                  // 1500ms (break between characters)
                      2,2,2,0,2,2,2,0,2,2,2,  // 5500ms (dash dash dash)
                      0,0,0,                  // 1500ms (break between characters)
                      1,0,1,0,1,              // 2500ms (dot dot dot)
                      0,0,0,0,0,0,0           // 3500ms (break between words)
};

int okLEDs[] = {
                     2,2,2,0,2,2,2,0,2,2,2,   // 5500ms (dash dash dash)
                     0,0,0,                   // 1500ms (break between characters)
                     2,2,2,0,1,0,2,2,2,       // 4500ms (dash dot dash)
                     0,0,0,0,0,0,0            // 3500ms (break between words)
};

/*
 * ======== timer functions =========
 *
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status){

    if (BUTTON_INIT == MC_SOS) {
        //set char at i in led array to variable ledState
        ledState = sosLEDs[i];

        switch(ledState) {
        // No lights (breaks between characters and words)
            case 0:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                break;
        // Red light only (dots)
            case 1:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                break;
        // Green light only (dashes)
            case 2:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
                break;
        }

        i++;
        // if end of array is completed
        if (i == 34){
            // set button initial state to current state (repeat SOS unless button is pressed)
            BUTTON_INIT = BUTTON_STATE;
            //restart count
            i = 0;
        }
    }

    if (BUTTON_INIT == MC_OK) {
        //set char at i in led array to variable ledState
        ledState = okLEDs[i];

        switch(ledState) {
        // No lights (breaks between characters and words)
            case 0:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                break;
        // Red light only (dots)
            case 1:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                break;
        // Green light only (dashes)
            case 2:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
                break;
        }

        i++;
        // if end of array is completed
        if (i == 30){
            // set button initial state to current state (repeat OK unless button is pressed)
            BUTTON_INIT = BUTTON_STATE;
            //restart count
            i = 0;
        }
    }
}


void initTimer(void){
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index){

    // check initial button state / toggle state
    if(BUTTON_INIT == MC_SOS){
        BUTTON_STATE = MC_OK;
    }
    if(BUTTON_INIT == MC_OK){
        BUTTON_STATE = MC_SOS;
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0){

    /* Call driver init functions */
    GPIO_init();


    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Start with LEDs off */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    initTimer();
    return (NULL);
}
